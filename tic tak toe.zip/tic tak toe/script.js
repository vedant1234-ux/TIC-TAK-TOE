document.addEventListener('DOMContentLoaded', function () {
    const board = document.getElementById('board');
    const cells = [];
    const result = document.getElementById('result');
    const resultMessage = document.getElementById('result-message');
    const newGameButton = document.getElementById('new-game');

    let currentPlayer = 'X';
    let gameBoard = ["", "", "", "", "", "", "", "", ""];

    // Create the Tic Tac Toe board
    for (let i = 0; i < 9; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.dataset.index = i;
        cell.addEventListener('click', handleCellClick);
        board.appendChild(cell);
        cells.push(cell);
    }

    // Handle cell click
    function handleCellClick(event) {
        const index = event.target.dataset.index;

        if (gameBoard[index] === "") {
            gameBoard[index] = currentPlayer;
            cells[index].textContent = currentPlayer;

            if (checkWinner()) {
                showResult(`${currentPlayer} wins!`);
            } else if (!gameBoard.includes("")) {
                showResult("It's a draw!");
            } else {
                currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            }
        }
    }

    // Check for a winner
    function checkWinner() {
        const winConditions = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6]             // Diagonals
        ];

        for (const condition of winConditions) {
            const [a, b, c] = condition;
            if (gameBoard[a] !== "" && gameBoard[a] === gameBoard[b] && gameBoard[b] === gameBoard[c]) {
                return true;
            }
        }

        return false;
    }

    // Show result screen
    function showResult(message) {
        resultMessage.textContent = message;
        result.style.display = 'block';
    }

    // Hide result screen
    function hideResult() {
        result.style.display = 'none';
    }

    // New game button click event
    newGameButton.addEventListener('click', function () {
        gameBoard = ["", "", "", "", "", "", "", "", ""];
        cells.forEach(cell => cell.textContent = "");
        hideResult();
        currentPlayer = 'X';
    });
});
